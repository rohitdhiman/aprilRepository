//
//  JSONFlickrAppDelegate.h
//  JSONFlickr
//
//  Created by John on 8/21/09.
//  Copyright iPhoneDeveloperTips.com 2009. All rights reserved.
//

@class JSONFlickrViewController;

@interface JSONFlickrAppDelegate : NSObject <UIApplicationDelegate> 
{
  UIWindow *window;
  JSONFlickrViewController *viewController;
}

@end

